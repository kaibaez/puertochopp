@extends('adminlte::page')

@section('title', 'Panel Inicial')

@section('content_header')
    <h1>Panel Inicial</h1>
@stop

@section('content')
    <p>Bienvenido al Sistema de Puerto Chopp.</p>
@stop

@section('footer')
    <p>Sistema proveído por Consultora Proyecto San José S.A. </p>
@stop
