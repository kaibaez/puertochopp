

<?php $__env->startSection('title', 'Barrios | Editar'); ?>
<?php $__env->startSection('content_header'); ?>
    <h2>Editar Barrio</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="card">
        <div class="card-body">
            <?php echo Form::model($barrio, ['route'=> ['bs.barrios.update',$barrio], 'method' => 'put']); ?>

                <?php echo $__env->make('bs.barrios.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php echo Form::submit('Actualizar barrio', ['class' => 'btn btn-primary']); ?>

                <a class="btn btn-secondary" href="<?php echo e(route('bs.barrios.index')); ?>">Cancelar</a>
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/bs/barrios/edit.blade.php ENDPATH**/ ?>