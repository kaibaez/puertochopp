
<?php $__env->startSection('title', 'Ciudad | Editar'); ?>
<?php $__env->startSection('content_header'); ?>
    <h2>Editar Ciudad</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="card">
        <div class="card-body">
            <?php echo Form::model($ciudad, ['route'=> ['bs.ciudades.update',$ciudad], 'method' => 'put']); ?>

                <?php echo $__env->make('bs.ciudades.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php echo Form::submit('Actualizar Ciudad', ['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/bs/ciudades/edit.blade.php ENDPATH**/ ?>