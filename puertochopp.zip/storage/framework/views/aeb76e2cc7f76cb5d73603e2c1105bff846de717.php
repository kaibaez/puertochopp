

<?php $__env->startSection('title', 'Cargos | Crear'); ?>
<?php $__env->startSection('content_header'); ?>
    <h2>Creaci&oacute;n de Cargos</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="card">
        <div class="card-body">
            <?php echo Form::open(['route'=>'rh.cargos.store']); ?>

                <?php echo $__env->make('rh.cargos.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
            <?php echo Form::submit('Crear Cargo', ['class' => 'btn btn-primary']); ?>

                <?php echo $__env->make('rh.cargos.partials.cancel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/rh/cargos/create.blade.php ENDPATH**/ ?>