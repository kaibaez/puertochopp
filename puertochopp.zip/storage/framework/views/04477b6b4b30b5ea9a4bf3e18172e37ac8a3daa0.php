<div class="form-group">
    <?php echo Form::label('descripcion', 'Descripci&oacute;n'); ?>

    <?php echo Form::text('descripcion',null, ['class' => 'form-control', 'placeholder' => 'Descripci&oacute;n']); ?>


    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="text-danger"><?php echo e($message); ?></span>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <?php echo Form::label('pais_id', 'Pais'); ?>

    <?php echo Form::select('pais_id',$paises, null, ['class' => 'form-control', 'placeholder' => 'Pais']); ?>

</div>        
<div class="form-group">
    <?php echo Form::label('estado', 'Estado'); ?>

    <div class="form-check">
        <?php echo Form::radio('estado', 'A',null,['class' => 'form-check-input']); ?>Activo &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo Form::radio('estado', 'I',null,['class' => 'form-check-input']); ?>Inactivo   
    </div>  
</div><?php /**PATH C:\wamp64\www\puertochopp\resources\views/bs/ciudades/partials/form.blade.php ENDPATH**/ ?>