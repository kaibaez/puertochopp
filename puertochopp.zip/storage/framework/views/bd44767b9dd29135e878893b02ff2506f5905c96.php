<?php $__env->startSection('title', 'Panel Inicial'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Panel Inicial</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido al Sistema de Puerto Chopp.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <p>Sistema proveído por Consultora Proyecto San José S.A. </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/home.blade.php ENDPATH**/ ?>