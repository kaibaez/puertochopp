

<?php $__env->startSection('title', 'Sucursales | Editar'); ?>
<?php $__env->startSection('content_header'); ?>
    <h2>Editar Sucursales</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="card">
        <div class="card-body">
            <?php echo Form::model($sucursal, ['route'=> ['bs.sucursales.update',$sucursal], 'method' => 'put']); ?>

                <?php echo $__env->make('bs.sucursales.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                <?php echo Form::submit('Actualizar Sucursal', ['class' => 'btn btn-primary']); ?>

                <?php echo $__env->make('bs.sucursales.partials.cancel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/bs/sucursales/edit.blade.php ENDPATH**/ ?>