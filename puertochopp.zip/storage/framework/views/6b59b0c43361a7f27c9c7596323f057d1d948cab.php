<div class="row">
    <div class="col-7">
        <div class="form-group">
            <?php echo Form::label('nombres', 'Nombres del empleado'); ?>

            <?php echo Form::text('nombres',null, ['class' => 'form-control', 'placeholder' => 'Nombres del empleado']); ?>

        
            <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    
    <div class="col-5">
        <div class="form-group">
            <?php echo Form::label('imagen', 'Foto del Empleado'); ?>

            <?php echo Form::file('photo'); ?>        
        </div>
    </div>
</div>

<div class="row">
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('apellidos', 'Apellidos del empleado'); ?>

            <?php echo Form::text('apellidos',null, ['class' => 'form-control', 'placeholder' => 'Apellidos del empleado']); ?>

        
            <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <?php echo Form::label('documento', 'Documento / CI'); ?>

            <?php echo Form::number('documento',null, ['class' => 'form-control', 'placeholder' => 'Documento del empleado']); ?>

        
            <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <?php echo Form::label('direcciones', 'Direcci&oacute;n'); ?>

            <?php echo Form::text('direcciones',null, ['class' => 'form-control', 'placeholder' => 'Direcci&oacute;n']); ?>

        
            <?php $__errorArgs = ['direcciones'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>        
    </div>    
</div>
<div class="row">
    <div class="col-4">
        <div class="form-group">
            <?php echo Form::label('pais_id', 'Nacionalidad / Pais'); ?>

            <?php echo Form::select('pais_id',$paises, null, ['class' => 'form-control', 'placeholder' => 'Pais de Nacionalidad']); ?>

        </div>        
    </div>
    <div class="col-4">
        <div class="form-group">
            <?php echo Form::label('ciudad_id', 'Ciudad de Residencia'); ?>

            <?php echo Form::select('ciudad_id',$ciudades, null, ['class' => 'form-control', 'placeholder' => 'Ciudad de Residencia']); ?>        
        </div>    
    </div>
    <div class="col-4">
        <div class="form-group">
            <?php echo Form::label('barrio_id', 'Barrio de Residencia'); ?>

            <?php echo Form::select('barrio_id',$barrios, null, ['class' => 'form-control', 'placeholder' => 'Barrio de Residencia']); ?>

        </div>
    </div>
</div>
<div class="row">
    <div class="col-12">
        <div class="form-group">
            <?php echo Form::label('fec_nacimiento', 'Fec.Nacimiento'); ?>

            <?php echo Form::date('fec_nacimiento',null, ['class' => 'form-control', 'placeholder' => 'Fec. Nacimiento']); ?>

        </div>
    </div>
</div>
<div class="card card-info">
    <div class="card-header">
        Sueldos y Anticipos
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <?php echo Form::label('salario', 'Salario'); ?>

                    <?php echo Form::number('salario',null, ['class' => 'form-control', 'placeholder' => 'Salario']); ?>

                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <?php echo Form::label('salario_ips', 'Salario IPS'); ?>

                    <?php echo Form::number('salario_ips',null, ['class' => 'form-control', 'placeholder' => 'Salario IPS']); ?>

                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <?php echo Form::label('anticipo', 'Anticipo'); ?>

                    <?php echo Form::number('anticipo',null, ['class' => 'form-control', 'placeholder' => 'Anticipo']); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<div class="card card-warning">
    <div class="card-header">
        Puesto Laboral
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-6">
               <div class="form-group">
                    <?php echo Form::label('fec_ingreso', 'Fec. Ingreso'); ?>

                    <?php echo Form::date('fec_ingreso',null, ['class' => 'form-control', 'placeholder' => 'Fec. Ingreso']); ?>

                </div>
            </div>
            <div class="col-6">
                <div class="form-group">
                    <?php echo Form::label('estado', 'Estado del cargo'); ?>

                    <div class="form-check">
                        <?php echo Form::radio('estado', 'A',null,['class' => 'form-check-input']); ?>Activo &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo Form::radio('estado', 'I',null,['class' => 'form-check-input']); ?>Inactivo   
                    </div>  
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-4">
                <div class="form-group">
                    <?php echo Form::label('cargo_id', 'Cargo del Empleado'); ?>

                    <?php echo Form::select('cargo_id',$cargos, null, ['class' => 'form-control', 'placeholder' => 'Cargo del Empleado']); ?>

                </div>
            </div>
            <div class="col-4">
                <div class="form-group">
                    <?php echo Form::label('seccion_id', 'Secci&oacute;n del Empleado'); ?>

                    <?php echo Form::select('seccion_id',$secciones, null, ['class' => 'form-control', 'placeholder' => 'Secci&oacute;n del Empleado']); ?>

                </div>
            </div>
            <div class="col-4"> 
                <div class="form-group"> 
                    <?php echo Form::label('sucursal_id', 'Sucursal del Empleado'); ?>

                    <?php echo Form::select('sucursal_id',$sucursales, null, ['class' => 'form-control', 'placeholder' => 'Sucursal del Empleado']); ?>

                </div>
            </div>
        </div>
    </div>
</div>







<?php /**PATH C:\wamp64\www\puertochopp\resources\views/rh/empleados/partials/form.blade.php ENDPATH**/ ?>