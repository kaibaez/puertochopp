

<?php $__env->startSection('title', 'Barrios'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Barrios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-header">
            <a href="<?php echo e(route('bs.barrios.create')); ?>" class="btn btn-success btn-sm "><i class="fa fa-plus"> Nueva barrio</i></a>
        </div>
        <?php if(session('store')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('store')); ?></strong>	
            </div>
        <?php elseif(session('update')): ?>
            <div class="alert alert-warning">
                <strong><?php echo e(session('update')); ?></strong>	
            </div>
        <?php elseif(session('destroy')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('destroy')); ?></strong>	
            </div>
        <?php endif; ?>
        <div class="card-body">
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>barrios</th>
                        <th>ciudad</th>
                        <th colspan="2">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $barrios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barrio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($barrio->id); ?></td>
                            <td><?php echo e($barrio->descripcion); ?></td>
                            <td><?php echo e($barrio->ciudad->descripcion); ?></td>
                            <td width="3px"><a class="btn btn-warning btn-xs" href="<?php echo e(route('bs.barrios.edit', $barrio)); ?>"><i class="fa fa-edit"></i></a></td>
                            <td width="3px">
                                <form action="<?php echo e(route('bs.barrios.destroy', $barrio)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <button type="submit" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/bs/barrios/index.blade.php ENDPATH**/ ?>