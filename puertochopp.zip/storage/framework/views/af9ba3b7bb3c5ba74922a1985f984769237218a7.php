

<?php $__env->startSection('title', 'Sucursales | Crear'); ?>
<?php $__env->startSection('content_header'); ?>
    <h2>Creaci&oacute;n de Sucursales</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>    
    <div class="card">
        <div class="card-body">
            <?php echo Form::open(['route'=>'bs.sucursales.store']); ?>

                <?php echo $__env->make('bs.sucursales.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
            <?php echo Form::submit('Crear Sucursal', ['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\puertochopp\resources\views/bs/sucursales/create.blade.php ENDPATH**/ ?>